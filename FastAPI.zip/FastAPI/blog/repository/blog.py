from sqlalchemy.orm import Session
from ..import models
from blog.database import get_db
from ..import schemas
from fastapi import HTTPException,status,Response,Depends
from ..routers import blog

def get_all(db:Session):
    blogs = db.query(models.Blog).all()
    return blogs

def create(request:schemas.Blog,db:Session):
    new_blog = models.Blog(title=request.title, body=request.body, user_id=1)
    db.add(new_blog)
    db.commit()
    db.refresh(new_blog)
    return new_blog

def destroy(id:int, db:Session):
    blog = db.query(models.Blog).filter(models.Blog.id== id)
    if not blog.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail=f"Blog with id {id} not found")
    blog.delete(synchronize_session=False)
    db.commit()
    return 'done'

def update(id: int, request: schemas.Blog, db: Session = Depends(get_db)):
    blog = db.query(models.Blog).filter(models.Blog.id == id).first()
    if not blog:
             raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f'blog with id {id} not found')
    else:
         db.query(models.Blog).filter(models.Blog.id == id).update(request.dict())
    

    #

    # Refresh to get the latest data (optional)
    # updated_blog = db.query(models.Blog).filter(models.Blog.id == id).first()
    # return updated_blog

"""def update(id:int,request:schemas.Blog, db:Session=Depends(get_db)):
    blog =db.query(models.Blog).filter(models.Blog.id == id).first()
    if not blog:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail=f"Blog with id {id} not found")
    blog.update(synchronize_session=False) 
    db.commit()
    updated_blog = db.query(models.Blog).filter(models.Blog.id == id).first()
    return updated_blog"""

def show(id:int, db:Session):
    blog =db.query(models.Blog).filter(models.Blog.id).first()
    if not blog:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Blog the id {id} is not available")
    """Response.status_code = status.HTTP_404_NOT_FOUND, detail =f"Blog with the id {id} is not availbale"""
    return blog
